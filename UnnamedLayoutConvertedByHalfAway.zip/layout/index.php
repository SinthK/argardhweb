<?php include 'layout/overall/header.php'; ?>

<h1>Hello!</h1>
<p>This layout is converted to ZnoteAAC by HalfAway, enjoy!</p>

<?php include 'layout/overall/footer.php'; ?>