					<div class="spacer_left"></div>
						<div class="widget_title"><img src="layout/images/menu/icon-news.gif">News</div>
					<div class="spacer_left"></div>
					<ul>
						<li><a href="index.php">Latest News</a></li>
						<li><a href="changelog.php">Changelog</a></li>
					<ul>
					<div class="spacer_left"></div>
						<div class="widget_title"><img src="layout/images/menu/icon-community.gif">Community</div>
					<div class="spacer_left"></div>
					<ul>
						<li><a href="onlinelist.php">Who is online?</a></li>
						<li><a href="forum.php">Forum</a></li>
						<li><a href="downloads.php">Downloads</a></li>
						<li><a href="highscores.php">Highscores</a></li>
						<li><a href="deaths.php">Latest deaths</a></li>
						<li><a href="guilds.php">Guilds</a></li>
						<li><a href="guildwar.php">Guild wars</a></li>
						<li><a href="killers.php">Top Fraggers</a></li>
						<li><a href="support.php">Support</a></li>
					<ul>
					<div class="spacer_left"></div>
						<div class="widget_title"><img src="layout/images/menu/icon-shops.gif">Shop</div>
					<div class="spacer_left"></div>
					<ul>
						<li><a href="shop.php">Shop offer</a></li>
						<li><a style="color: yellow;" href="buypoints.php">Buy points</a></li>
					<ul>