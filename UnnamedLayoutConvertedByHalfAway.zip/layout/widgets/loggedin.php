	<div class="widget_title"><img src="layout/images/menu/icon-forum.gif">My Account</div>
	<div class="spacer_right"></div>
		<ul>
			<li>
				<a href='myaccount.php' class='playerlink'>My Account</a>
			</li>
			<li>
				<a href='createcharacter.php' class='playerlink'>Create Character</a>
			</li>
			<li>
				<a href='changepassword.php' class='playerlink'>Change Password</a>
			</li>
			<li>
				<a href='settings.php' class='playerlink'>Settings</a>
			</li>
			<li>
				<a href='logout.php' class='playerlink'>Logout</a>
			</li>
		</ul>