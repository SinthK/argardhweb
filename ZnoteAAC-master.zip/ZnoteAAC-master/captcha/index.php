<?php header('Location: ../pages/frontpage.php'); ?>
