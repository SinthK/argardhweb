-- Znote Shop v1.0 for Znote AAC on TFS 0.3.6+ Crying Damson.
function onSay(cid, words, param)
	local storage = 54073 -- Make sure to select non-used storage. This is used to prevent SQL load attacks.
	local cooldown = 15 -- in seconds.
	
	if getPlayerStorageValue(cid, storage) <= os.time() then
		setPlayerStorageValue(cid, storage, os.time() + cooldown)
		local accid = getAccountNumberByPlayerName(getCreatureName(cid))
		
		-- Create the query
		local orderQuery = db.storeQuery("SELECT `id`, `type`, `itemid`, `count` FROM `znote_shop_orders` WHERE `account_id` = " .. accid .. " LIMIT 1;")
		
		-- Detect if we got any results
		if orderQuery ~= false then
			-- Fetch order values
			local q_id = result.getDataInt(orderQuery, "id")
			local q_type = result.getDataInt(orderQuery, "type")
			local q_itemid = result.getDataInt(orderQuery, "itemid")
			local q_count = result.getDataInt(orderQuery, "count")
			result.free(orderQuery)
			-- ORDER TYPE 1 (Regular item shop products)
			if q_type == 1 then
				-- Get wheight
				local playerCap = getPlayerFreeCap(cid)
				local itemweight = getItemWeightById(q_itemid, q_count)
					if playerCap >= itemweight and getTileInfo(getCreaturePosition(cid)).protection then
						--backpack check
						local backpack = getPlayerSlotItem(cid, 3)
						local gotItem = false
						if(backpack and backpack.itemid > 0) then
							local received = doAddContainerItem(getPlayerSlotItem(cid, 3).uid, q_itemid,q_count)
							if(received ~= false) then
								db.executeQuery("DELETE FROM `znote_shop_orders` WHERE `id` = " .. q_id .. ";")
								doPlayerSendTextMessage(cid, MESSAGE_INFO_DESCR, "Congratulations! You have recieved ".. q_count .." "..getItemNameById(q_itemid).."(s)!")
								gotItem = true
							end
						end

						if(not gotItem) then
							doPlayerSendTextMessage(cid, MESSAGE_STATUS_WARNING, "You have no available space in backpack to receive that item.")
						end						
					else
						doPlayerSendTextMessage(cid, MESSAGE_STATUS_WARNING, "Need more CAP and Need ProtectZone!")
					end
			end
			-- Add custom order types here
			-- Type 2 is reserved for premium days and is handled on website, not needed here.
			-- Type 3 is reserved for character gender(sex) change and is handled on website as well.
			-- So use type 4+ for custom stuff, like etc packages.
			-- if q_type == 4 then
			-- end
		else
			doPlayerSendTextMessage(cid, MESSAGE_STATUS_WARNING, "You have no orders.")
		end
		
	else
		doPlayerSendTextMessage(cid, MESSAGE_STATUS_CONSOLE_BLUE, "Can only be executed once every "..cooldown.." seconds. Remaining cooldown: ".. getPlayerStorageValue(cid, storage) - os.time())
	end
	return false
end